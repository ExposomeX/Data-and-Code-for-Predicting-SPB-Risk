
rm(list = ls())

# Step 0. Start  ----------------------------------------------------------
#load packages
PID = "A1" 
FileDirIn = "default" 
FileDirOut = "default" 
#PID: chr; Program ID, Any characters can be set. If "auto", a six randomly characters will be generated. #This is the unique ID of an analysis using this module.
#FileDirIn: chr; Output file directory Users can choose any path for the output files. If "defaults", the current working path will be used. #Or choose the target file directory: e.g "D:/王斌/Module_Expoverse" 
#FileDirOut: chr; Output file directory Users can choose any path for the output files. If "defaults", the current working path will be used. #Or choose the target file directory: e.g "D:/王斌/Module_Expoverse" 

source("functions/code for load packages.R")  
eSet <- InitExpoData(PID = PID,
                     FileDirIn = FileDirIn,
                     FileDirOut = FileDirOut)

# Step 1. Upload data ------------------------------------------------------------
#LoadData
PID = "A1" 
UseExample = "default"
FileDirExpo = "continuous variables data.xlsx"
FileDirVoca = "continuous variables voca.xlsx"
#UseExample: chr; the "default" mode is user input their own data files, or use "example#1" etc.
#FileDirExpo: chr; Target file directory of exposome data: e.g "D:/王斌/Module_Expoverse" 
#FileDirVoca: chr; Target file directory of exposome vocabulary data: e.g "D:/王斌/Module_Expoverse" 

source("functions/code for load data.R")  # "source" will be deleted after debugging the program
eSet <- LoadData(eSet = eSet,
                 UseExample = UseExample,
                 FileDirExpo = FileDirExpo,      
                 FileDirVoca = FileDirVoca
)

# Step 2. Tidy data ------------------------------------------------------------
#Step 2.1. code for tidy data
PID = "A1" 
source("functions/code for tidy data.R") 
eSet <- Tidydata(eSet = eSet) 

#2.2 TransType
PID = "A1" 
TransTypeVars = c("Y1")
TransTypeTo = "factor"
#TransTypeVars: chr; Vars to be transformed
#TransTypeTo: chr; Type to be transformed, i.e. "integer" "numeric" "character" "factor" "logical" "date"

source("functions/code for transform type.R") 
eSet <- TransType(eSet = eSet,
                  Vars = TransTypeVars,  
                  TypeTo = TransTypeTo
)

##2.3 TransScale
PID = "A1" 
TransScaleVars = "all.x"
#TransImputGroup: logical
#TransScaleVars: chr; Vars to be transformed to noraml
source("functions/code for transform scale.R") 
eSet <- TransScale(eSet = eSet,
                   Vars = TransScaleVars
)

# Step 3.  screen potential risk factors ------------------------------------------------------------
PID = "A1"
CrosAssoVarsY = "Y1"
CrosAssoVarsX = "all.x"
CrosAssoVarsSel = T
CrosAssoVarsSelThr = 0.1
CrosAssoFamily = "binomial"
CrosAssoRepMsr = T
CrosAssoCorstr = "ar1"
#CrosAssoVarsY: chr
#CrosAssoVarsX: chr
#CrosAssoFamily:
# gaussian
# binomial
# binomial
# poisson
#CrosAssoRepMsr: logical i.e. TRUE FALSE
#CrosAssoCorstr: chr, i.e. "exchangeable" "ar1" "unstructured" 

source("functions/code for screen association.R") 
eSet <- CrosAsso(eSet = eSet,
                 VarsY = CrosAssoVarsY,
                 VarsX = CrosAssoVarsX,
                 VarsSel = CrosAssoVarsSel,
                 VarsSelThr = CrosAssoVarsSelThr,
                 Family = CrosAssoFamily,
                 RepMsr = CrosAssoRepMsr,
                 Corstr = CrosAssoCorstr
)

# Step 4. prediction model ------------------------------------------------------------
OmicGroups = c("chemical","immune","metabolome")
VarY = c("Y1")
VarsC = NULL
AutTuneM = "random_search"
AutTuneN = 5
Folds = 5
Ratio = NULL
Repeats = NULL
VarsImpThr = 0.85
NodeNum = 40
EdgeThr = 0.45
#OmicGroups: chr; OmicGroups to be integrated; Refer to your data sheet 
#VarsY: chr; Outcome you concern; Refer to your data sheet 
#VarsC: chr; Covariate to be included; Refer to your data sheet 
#AutTuneM: chr; Method for hyper-parameter autotuning; 
#- random_search - random search
#- grid_search - grid search
#- gensa - Generalized Simulated Annealing
#- nloptr - Non-Linear Optimization
#AutTuneN: numeric; times tuner try
#Folds; numeric; Folds for cv; 
#VarsImpThr: numeric; Variable importance Threshold for feature selection; 0-1
#SG_Lrns: chr; learners for SG; "lasso","elastic net","randomforest","xgboost"
#NodeNum: numeric; Node number of network; 
#EdgeThr:numeric; Threshold of correlation coefficient for generating edge
source("functions/code for prediction model.R", encoding = "utf-8") 
eSet <- MulOmics(eSet = eSet,
                 OmicGroups = OmicGroups,
                 VarsY = VarsY,
                 VarsC = VarsC,
                 AutTuneM = AutTuneM,
                 AutTuneN = AutTuneN,
                 Folds = Folds,
                 Ratio = Ratio,
                 Repeats = Repeats,
                 VarsImpThr = VarsImpThr,
                 NodeNum = NodeNum,
                 EdgeThr = EdgeThr)

