
InitExpoData <- function(PID = "default",
                         FileDirIn = "default",
                         FileDirOut = "default"
                         ){

# install the required packages ----------------------------------------------------------
  as.data.frame(installed.packages())[,1] -> pkg_all
    
  if(!"pacman" %in% pkg_all){
    quiet(install.packages("pacman"))
  }
  
  if(!"mlr3extralearners" %in% pkg_all){
    quiet(devtools::install_github("https://github.com/mlr-org/mlr3extralearners.git"))
  }
  
  pacman::p_load(
     "BiocManager", 
     "bestNormalize",
     "broom",
     "car",
     "caret",
     "DALEX",
     "DALEXtra",
     "data.table",
     "ddpcr",
     "devtools",
     "factoextra",
     "fs",
     "gee",
     "geepack",
     "gtsummary",
     "lmtest",
     "lubridate",
     "mice",
     "mlr3verse",
     "mlr3viz",
     "mlr3extralearners",
     "magrittr",
     "naniar",
     "R6",
     "RCy3",
     "tidyverse",
     "tictoc",
     "vip",
     "vroom",
     "rstatix",
     "ggplot2",
     "ggfortify",
     "GGally",
     "patchwork",
     "precrec",
     "zip",
     #below machine learning
     "C50",
     "cluster",
     "coin",
     "dbarts",
     "e1071",
     "earth",
     "FNN",
     "gbm",
     "glmnet",
     "kernlab",
     "kknn",
     "LiblineaR",
     "lightgbm",
     "MASS",
     "mboost",
     "mgcv",
     "nnet",
     "partykit",
     "ranger",
     "rpart",
     "sandwich",
     "stats",
     "xgboost"
     )
    
message("Reminder: If any packages cann't be installed, please install them by referring the tutorial files. \n")
    
tictoc::tic()
lubridate::now() %>% 
  stringr::str_replace_all(":",".") %>% 
  stringr::str_replace_all("-",".") -> NowTime 

# create R6 class eSet ----------------------------------------------------
    eSet <- R6::R6Class(
      "eSet",
      public = list(
        PID = NULL,
        EpiDesign = NULL,
        DataStr = NULL,
        FileDirIn = NULL,
        FileDirOut = NULL,
        ExcecutionLog = NULL,
        RCommandLog = NULL,
        Expo = list(Data = NULL,
                    Voca = NULL),
        ExpoDel = list(Data = NULL,
                       Voca = NULL),
        
        AddLog = function(x){
          self$ExcecutionLog = c(self$ExcecutionLog, 
                                 stringr::str_c(x))},
        
        AddCommand = function(x){
          self$RCommandLog = c(self$RCommandLog, 
                                 stringr::str_c(x))},
        
        initialize = function(FileDirIn,
                              FileDirOut) {
          self$FileDirIn = FileDirIn
          self$FileDirOut = FileDirOut
          }
        ),
      
      lock_class = FALSE,
      lock_objects = FALSE
      )

    eSet <- eSet$new(FileDirIn = FileDirIn,
                     FileDirOut = FileDirOut)

  # generate default PID
    if(PID != "default"){
      eSet$PID <- PID
    }else{
      eSet$PID <- stringr::str_c(lubridate::now() %>% 
                         stringr::str_remove_all(" ") %>% 
                         stringr::str_remove_all("-") %>%
                         stringr::str_remove_all(":") %>%
                         stringr::str_sub(9,-1),
                       collapse = "") %>% 
        stringr::str_c(sample(c("A","B","C","D","E","F","G","H","J","K","L","M","N","P","Q","R","S","T","U","V","W","X","Y","Z"),
                              6, replace = TRUE) %>% 
                         stringr::str_c(collapse = ""))
      }
    
    
  # initialize the model bank -----------------------------------------------
    readxl::read_xlsx("data/model.bank.xlsx")  %>% 
      dplyr::filter(!key %in% c("classif.gamboost",
                                "classif.qda",
                                "regr.gamboost"
                                )
                    ) -> eSet$ModelBank

  # initialize the folder ---------------------------------------------------
  if(FileDirIn == "default"){
    stringr::str_c(getwd(), 
                   "/input_", 
                   eSet$PID) -> eSet$FileDirIn
    
    if(!file.exists(eSet$FileDirIn)){
      dir.create(eSet$FileDirIn)
    }
  }else if(!file.exists(FileDirIn)){
    stringr::str_c(FileDirIn,
                   "/input_", 
                   eSet$PID) -> eSet$FileDirIn
    dir.create(eSet$FileDirIn)
  }
    
    
 if(FileDirOut == "default"){
   stringr::str_c(getwd(), 
                  "/output_", 
                  eSet$PID) -> eSet$FileDirOut
   
   if(!file.exists(eSet$FileDirOut)){
     dir.create(eSet$FileDirOut)
   }
 }else if(!file.exists(FileDirOut)){
   stringr::str_c(FileDirOut,
                  "/output_", 
                  eSet$PID) -> eSet$FileDirOut
   dir.create(eSet$FileDirOut)
 }
  
  # initialize functions -----------------------------------------------
  for(func in list.files("functions/")){
    source(str_c("functions/",
                 func))$value -> eSet$Func[[str_sub(func,1,-3)]]}
    

  # save eSet ----
  eSet %>% 
    save(file = str_c(eSet$FileDirOut,"/eSet.Rdata"))
  
  tictoc::toc()  
  
  return(eSet)
}
