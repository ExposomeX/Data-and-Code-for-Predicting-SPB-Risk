
TransType <- function(eSet,
                      Vars, 
                      TypeTo #integer, numeric, character, factor, logical, date
                      ){
  tictoc::tic()
  lubridate::now() %>% 
    stringr::str_replace_all(":",".") %>% 
    stringr::str_replace_all("-",".") -> NowTime 
  
  path = stringr::str_c(eSet$FileDirOut, "/3_transform type")
  if(!file.exists(path)) {dir.create(path)}
 
  #check the loading data

  # Define data -----------------------------------------------------------------------------
  eSet$Expo$Data  -> df.all

  
  # func_data.type -----------------------------------------------------------------------------
  switch(TypeTo,
         "integer" = {
             df.all %>% 
               dplyr::mutate(dplyr::across(all_of(Vars), as.integer)) -> eSet$Expo$Data
           },
         "numeric" = {
           ddpcr::quiet(
           df.all %>% 
             dplyr::mutate(dplyr::across(all_of(Vars), as.numeric)) -> eSet$Expo$Data
           )
           },
         "character" = {
             df.all %>% 
               dplyr::mutate(dplyr::across(all_of(Vars), as.character)) -> eSet$Expo$Data
           },
         "factor" = {
             df.all %>% 
               dplyr::mutate(dplyr::across(all_of(Vars), as.factor)) -> eSet$Expo$Data
           },
         "logical" = {
             df.all %>% 
               dplyr::mutate(dplyr::across(all_of(Vars), as.logical)) -> eSet$Expo$Data
           },
         "date" = {
             df.all %>% 
               dplyr::mutate(dplyr::across(all_of(Vars), as_date)) -> eSet$Expo$Data
           }
  )

  #save data --------------------------------------------------------------------------------
  ddpcr::quiet(
    eSet$Expo$Data %>% 
      vroom::vroom_write(stringr::str_c(path, "/Data_TransDataTypeTo_", TypeTo, "_", NowTime,".csv"),
                       delim = ",")
    )
    
  ddpcr::quiet(
    eSet$Expo$Voca %>% 
      vroom::vroom_write(stringr::str_c(path, "/Voca_TransDataTypeTo_", TypeTo, "_", NowTime,".csv"),
                       delim = ",")
  )
  
  #print message and save log
  message("Complete transform -> ", TypeTo, ". ",NowTime, "\n")
  eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Complete transform -> ", TypeTo, ". ", NowTime))
  
  eSet %>% 
    save(file = str_c(eSet$FileDirOut,"/eSet.Rdata"))
  
  tictoc::toc()
  
  return(eSet)
}





