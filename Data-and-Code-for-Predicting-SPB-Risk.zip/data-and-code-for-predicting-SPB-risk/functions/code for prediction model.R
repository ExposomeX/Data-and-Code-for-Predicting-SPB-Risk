# Omics model
MulOmics <- function(eSet,
                     OmicGroups,
                     VarsY,
                     VarsC,
                     AutTuneM = "random_search",
                     AutTuneN = "5",
                     Folds = "5",
                     Ratio = NULL,
                     Repeats = NULL,
                     VarsImpThr = 0.85,
                     NodeNum = 50,
                     EdgeThr = 0.45
){
  Path = stringr::str_c(eSet$FileDirOut,"/","6_prediction model")
  if(!file.exists(Path)) {dir.create(Path)}
  # Define single omics process ---------------------------------------------------------
  resampling = rsmp("cv", 
                    folds = Folds)
  
  task = "classif"
  pred.type = "prob"
  measure_key = "classif.acc"
  measure_id = "acc"
  svm.type = "C-classification"
  set_task = function(...){as_task_classif(...)}
  
  
  single.omics = function(OmicGroup,
                          VarY,
                          VarsC,
                          AutTuneM,
                          AutTuneN,
                          task,
                          pred.type,
                          measure_key,
                          measure_id,
                          set_task,
                          resampling){

    # creat folder
    if(!file.exists(str_c(Path,"/",OmicGroup))){
      dir.create(str_c(Path,"/",OmicGroup))
    }
    if(!file.exists(str_c(Path,"/",OmicGroup,"/Feature_Explain"))){
      dir.create(str_c(Path,"/",OmicGroup,"/Feature_Explain"))
    }
    if(!file.exists(str_c(Path,"/",OmicGroup,"/Features_Selection"))){
      dir.create(str_c(Path,"/",OmicGroup,"/Features_Selection"))
    }
    if(!file.exists(str_c(Path,"/",OmicGroup,"/Model_Summary"))){
      dir.create(str_c(Path,"/",OmicGroup,"/Model_Summary"))
    }
    
    
    lubridate::now() %>% 
      stringr::str_replace_all(":",".") %>% 
      stringr::str_replace_all("-",".") -> NowTime 
    
    message(stringr::str_c("Folder for ",OmicGroup," has been created!",NowTime))
    eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Folder for ",OmicGroup," has been created!",NowTime))
    message(stringr::str_c("Step1: Building machine learning models for ",OmicGroup," ...",NowTime))
    eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Step1: Building machine learning models for ",OmicGroup," ...",NowTime))
    # define data ------------------------------------------------------------- 
    eSet$MulOmics$OmicGroup.all <- c(eSet$MulOmics$OmicGroup.all,OmicGroup) # record Omics groups loaded
    
    VarsX <- eSet$Expo$Voca %>% filter(GroupName==OmicGroup) %>% dplyr::select(SerialNo) %>% as.matrix() %>% as.vector()
    
    eSet$Expo$Data %>% 
      filter(Group == "train") %>% 
      dplyr::select(all_of(VarY), 
                    all_of(VarsX),
                    all_of(VarsC)) -> df.all.train
    
    eSet$Expo$Data %>% 
      filter(Group == "test") %>% 
      dplyr::select(all_of(VarY), 
                    all_of(VarsX),
                    all_of(VarsC)) -> df.all.test
    
    # feature selection ---------------------------------------------------------
    df.all.train %>% 
      set_task(target = VarY) -> task0.train 
    # lasso
    learner_lasso = lrn(str_c(task,".cv_glmnet"), 
                        predict_type = pred.type,
                        predict_sets = c("train", "test"),
                        id = "lasso")
    learner_lasso$param_set$values = list(alpha = 1)
    learner_lasso$train(task0.train)  
    learner_lasso$selected_features(lambda = learner_lasso$model$lambda.1se) -> features_lasso 
    eSet$Expo$Voca %>% 
      filter(SerialNo %in% features_lasso) %>% 
      writexl::write_xlsx(str_c(Path,"/",
                                OmicGroup,
                                "/Features_Selection/Selected.features_lasso.xlsx"))
    # Save coefficients
    learner_lasso$model %>% coef(s='lambda.1se') %>% as.matrix -> Coef_lasso
    Coef_lasso %>% 
      as_tibble() %>% 
      set_names("Coef") %>% 
      mutate(SerialNo = rownames(Coef_lasso)) -> eSet$MulOmics[[OmicGroup]]$Features$Coef$Lasso
    
    eSet$MulOmics[[OmicGroup]]$Features$Coef$Lasso %>% 
      writexl::write_xlsx(str_c(Path,"/",
                                OmicGroup,
                                "/Features_Selection/Coefficients_lasso.xlsx"))
    # elastic net
    learner_elasticnet = lrn(str_c(task,".glmnet"), 
                             predict_type = pred.type,
                             predict_sets = c("train", "test"),
                             id = "elastic net")
    search_space = ps(
      alpha = p_dbl(lower = 0, upper = 1),
      lambda = p_dbl(lower = 0, upper = 1)
    )
    terminator = trm("evals", n_evals = AutTuneN)
    tuner = tnr(AutTuneM)
    at = AutoTuner$new(
      learner = learner_elasticnet,
      resampling = resampling,
      measure = msr(measure_key),
      search_space = search_space,
      terminator = terminator,
      tuner = tuner
    )
    
    lubridate::now() %>% 
      stringr::str_replace_all(":",".") %>% 
      stringr::str_replace_all("-",".") -> NowTime 
    
    message(stringr::str_c("Autotunning Elastic Net Model for Feature Selection... Please be patient!",NowTime))
    eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Autotunning Elastic Net Model for Feature Selection... Please be patient!",NowTime))
    ddpcr::quiet(at$train(task0.train))
    
    lubridate::now() %>% 
      stringr::str_replace_all(":",".") %>% 
      stringr::str_replace_all("-",".") -> NowTime 
    
    message(stringr::str_c("Elastic Net Model Autotune Accomplished!",NowTime))
    eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Elastic Net Model Autotune Accomplished!",NowTime))
    learner_elasticnet$param_set$values <- at$model$tuning_instance$result_learner_param_vals # 使用调参结果
    learner_elasticnet$train(task0.train)
    learner_elasticnet$selected_features() -> features_elasticnet 
    eSet$Expo$Voca %>% 
      filter(SerialNo %in% features_elasticnet) %>% 
      writexl::write_xlsx(str_c(Path,"/",
                                OmicGroup,
                                "/Features_Selection/Selected.features_elasticnet.xlsx"))
    # Save coefficients
    learner_elasticnet$model %>% coef(s='lambda.1se') %>% as.matrix -> Coef_elasticnet
    Coef_elasticnet %>% 
      as_tibble() %>% 
      set_names("Coef") %>% 
      mutate(SerialNo = rownames(Coef_elasticnet)) -> eSet$MulOmics[[OmicGroup]]$Features$Coef$Elasticnet
    
    eSet$MulOmics[[OmicGroup]]$Features$Coef$Elasticnet %>% 
      writexl::write_xlsx(str_c(Path,"/",
                                OmicGroup,
                                "/Features_Selection/Coefficients_elasticnet.xlsx"))
    
    # randomforest
    learner = lrn(str_c(task,".ranger"),
                  predict_type = pred.type)
    search_space = ps(
      max.depth = p_int(lower = 6, upper = 100),
      mtry.ratio = p_dbl(lower = 0.3, upper = 0.7),
      num.trees = p_int(lower = 10, upper = 500)
    )
    terminator = trm("evals", n_evals = AutTuneN)
    tuner = tnr(AutTuneM)
    at = AutoTuner$new(
      learner = learner,
      resampling = resampling,
      measure = msr(measure_key),
      search_space = search_space,
      terminator = terminator,
      tuner = tuner
    )
    
    lubridate::now() %>% 
      stringr::str_replace_all(":",".") %>% 
      stringr::str_replace_all("-",".") -> NowTime 
    
    message(stringr::str_c("Autotunning Random Forest Model for Feature Selection... Please be patient!",NowTime))
    eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Autotunning Random Forest Model for Feature Selection... Please be patient!",NowTime))
    ddpcr::quiet(at$train(task0.train))
    
    lubridate::now() %>% 
      stringr::str_replace_all(":",".") %>% 
      stringr::str_replace_all("-",".") -> NowTime 
    
    message(stringr::str_c("Random Forest Model Autotune Accomplished!",NowTime))
    eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Random Forest Model Autotune Accomplished!",NowTime))
    learner$param_set$values <- at$model$tuning_instance$result_learner_param_vals # set parameter
    learner$param_set$values$importance <- "permutation"
    learner$train(task0.train)
    learner$importance() %>% sort(decreasing=T) -> importance_rf
    # Save feature importance
    importance_rf %>% names() %>% tibble(SerialNo = .) %>% 
      mutate(importance = importance_rf) %>% 
      filter(importance > 0)  %>% 
      mutate(importance_perct = map_dbl(importance,
                                        ~(./sum(importance))),
             importance_perct_cum = cumsum(importance_perct))  -> eSet$MulOmics[[OmicGroup]]$Features$feature_importance$rf
    
    eSet$MulOmics[[OmicGroup]]$Features$feature_importance$rf %>% 
      left_join(eSet$Expo$Voca %>% dplyr::select(SerialNo,FullName),
                by = "SerialNo") %>% 
      writexl::write_xlsx(str_c(Path,"/",
                                OmicGroup,
                                "/Features_Selection/Importance_rf.xlsx"))
    eSet$MulOmics[[OmicGroup]]$Features$feature_importance$rf %>% 
      filter(importance_perct_cum <= VarsImpThr) %>% 
      dplyr::select(SerialNo) %>% as.matrix() %>% as.vector() -> features_rf # features selection
    eSet$Expo$Voca %>% 
      filter(SerialNo %in% features_rf) %>% 
      writexl::write_xlsx(str_c(Path,"/",
                                OmicGroup,
                                "/Features_Selection/Selected.features_rf.xlsx"))
    # xgboost
    learner = lrn(str_c(task,".xgboost"),
                  predict_type = pred.type)
    learner$param_set$values$eta = 0.1
    search_space = ps(
      subsample = p_dbl(lower = 0.5, upper = 1),
      colsample_bytree = p_dbl(lower = 0.5, upper = 1),
      max_depth = p_int(lower = 3, upper = 10),
      nrounds = p_int(lower = 2, upper = 200)
    )
    terminator = trm("evals", n_evals = AutTuneN)
    tuner = tnr(AutTuneM)
    at = AutoTuner$new(
      learner = learner,
      resampling = resampling,
      measure = msr(measure_key),
      search_space = search_space,
      terminator = terminator,
      tuner = tuner
    )
    
    lubridate::now() %>% 
      stringr::str_replace_all(":",".") %>% 
      stringr::str_replace_all("-",".") -> NowTime 
    
    message(stringr::str_c("Autotunning Xgboost Model for Feature Selection... Please be patient!",NowTime))
    eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Autotunning Xgboost Model for Feature Selection... Please be patient!",NowTime))
    ddpcr::quiet(at$train(task0.train))
    
    lubridate::now() %>% 
      stringr::str_replace_all(":",".") %>% 
      stringr::str_replace_all("-",".") -> NowTime 
    
    message(stringr::str_c("Xgboost Model Autotune Accomplished!",NowTime))
    eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Xgboost Model Autotune Accomplished!",NowTime))
    learner$param_set$values <- at$model$tuning_instance$result_learner_param_vals # set parameter
    learner$train(task0.train)
    learner$importance() %>% sort(decreasing=T) -> importance_xgboost
    # Save feature importance
    importance_xgboost %>% names() %>% tibble(SerialNo = .) %>% 
      mutate(importance = importance_xgboost) %>% 
      filter(importance > 0)  %>% 
      mutate(importance_perct = map_dbl(importance,
                                        ~(./sum(importance))),
             importance_perct_cum = cumsum(importance_perct)) -> eSet$MulOmics[[OmicGroup]]$Features$feature_importance$xgboost
    
    eSet$MulOmics[[OmicGroup]]$Features$feature_importance$xgboost %>% 
      left_join(eSet$Expo$Voca %>% dplyr::select(SerialNo,FullName),
                by = "SerialNo") %>% 
      writexl::write_xlsx(str_c(Path,"/",
                                OmicGroup,
                                "/Features_Selection/Importance_xgboost.xlsx"))
    
    eSet$MulOmics[[OmicGroup]]$Features$feature_importance$xgboost %>% 
      filter(importance_perct_cum <= VarsImpThr) %>% 
      dplyr::select(SerialNo) %>% as.matrix() %>% as.vector() -> features_xgboost # features selection
    eSet$Expo$Voca %>% 
      filter(SerialNo %in% features_xgboost) %>% 
      writexl::write_xlsx(str_c(Path,"/",
                                OmicGroup,
                                "/Features_Selection/Selected.features_xgboost.xlsx"))
    # # SVM
    # learner = lrn(str_c(task,".svm"),
    #               predict_type = pred.type)
    # learner$param_set
    # learner$param_set$values$type = "C-classification"
    # learner$param_set$values$kernel = "radial"
    # search_space = ps(
    #   cost = p_dbl(lower = 0, upper = 100),
    #   gamma = p_dbl(lower = 0, upper = 100)
    # )
    # terminator = trm("evals", n_evals = AutTuneN)
    # tuner = tnr(AutTuneM)
    # at = AutoTuner$new(
    #   learner = learner,
    #   resampling = resampling,
    #   measure = msr(measure_key),
    #   search_space = search_space,
    #   terminator = terminator,
    #   tuner = tuner
    # )
    # at$train(task0.train)
    # learner$param_set$values <- at$model$tuning_instance$result_learner_param_vals # set parameter
    # learner$train(task0.train)
    # vip::vi(learner$model)
    # DALEX::explain(model = learner$model,
    #                data = df.all.train[,-1],
    #                y = df.all.train$Y %>% as.character() %>% as.numeric(),
    #                label = "svm"
    #                )-> explainer_svm
    # model_parts(explainer = explainer_svm,
    #             B = 1,
    #             loos_function = "loss_accuracy") -> importance_svm
    # learner$importance() %>% sort(decreasing=T) -> importance_svm
    # importance_svm %>% names() %>% as_tibble %>% 
    #   mutate(importance = importance_svm) %>% 
    #   filter(importance > 0)  %>% 
    #   mutate(importance_perct = map_dbl(importance,
    #                                     ~(./sum(importance))),
    #          importance_perct_cum = cumsum(importance_perct)) -> eSet$MulOmics[[OmicGroup]]$Features$feature_importance$svm
    # eSet$MulOmics[[OmicGroup]]$Features$feature_importance$svm %>% 
    #   writexl::write_xlsx(str_c(Path,"/ModuleMulOmics/",
    #                            VarY,
    #                            "/",
    #                            OmicGroup,
    #                            "/importance_svm.xlsx"))
    #eSet$MulOmics[[OmicGroup]]$Features$feature_importance$svm %>% 
    #  filter(importance_perct_cum <= VarsImpThr) %>% 
    #  dplyr::select(value) %>% as.matrix() %>% as.vector() -> features_svm # features selection
    #features_svm %>% 
    #  as_tibble() %>% 
    #  writexl::write_xlsx(str_c("/ModuleMulOmics/",
    #                                VarY,
    #                                "/",
    #                            OmicGroup,
    #                            "/selected.features_svm.xlsx"))
    
    
    
    
    # save features selected
    list(lasso = features_lasso,
         elastic_net = features_elasticnet,
         rf = features_rf,
         xgboost = features_xgboost) -> eSet$MulOmics[[OmicGroup]]$Features$features_selected
    
    # Build model ---------------------------------------------------------
    # task lasso train
    df.all.train %>% 
      set_task(id = "lasso",
               target = VarY) -> task_lasso.train
    # task elastic net train
    df.all.train %>% 
      set_task(id = "elastic net",
               target = VarY) -> task_elasticnet.train
    # task ranger train
    df.all.train %>% 
      dplyr::select(all_of(VarY),
             all_of(features_rf)) %>% 
      set_task(id = "random forest",
               target = VarY) -> task_rf.train
    # task xgboost train
    df.all.train %>% 
      dplyr::select(all_of(VarY),
             all_of(features_xgboost)) %>% 
      set_task(id = "xgboost",
               target = VarY) -> task_xgboost.train
     # task svm train
     #df.all.train %>% dplyr::select(VarY,features_svm) %>% 
     #  set_task(id = "svm",
     #          target = VarY) -> task_svm.train
    
    # task ranger test
    df.all.test %>% 
      dplyr::select(all_of(VarY),
             all_of(features_rf)) -> newdt_rf.test
    # task xgboost test
    df.all.test %>% 
      dplyr::select(all_of(VarY),
             all_of(features_xgboost)) -> newdt_xgboost.test
     # task svm test
     #df.all.test %>% dplyr::select(VarY,features_svm) %>% 
     #  set_task(id = "svm",
     #            target = VarY) -> task_svm.test

    # learner lasso
    learner_lasso
    # learner elastic net
    learner_elasticnet 
    # learner ranger
    learner_rf <- lrn(str_c(task,".ranger"), 
                      predict_type = pred.type,
                      predict_sets = c("train", "test"),
                      id = "random forest")
    # auto-tune ranger
    search_space = ps(
      max.depth = p_int(lower = 6, upper = 100),
      mtry.ratio = p_dbl(lower = 0.3, upper = 0.7),
      num.trees = p_int(lower = 10, upper = 500)
    )
    terminator = trm("evals", n_evals = AutTuneN)
    tuner = tnr(AutTuneM)
    at_rf = AutoTuner$new(
      learner = learner_rf,
      resampling = resampling,
      measure = msr(measure_key),
      search_space = search_space,
      terminator = terminator,
      tuner = tuner
    )
    
    lubridate::now() %>% 
      stringr::str_replace_all(":",".") %>% 
      stringr::str_replace_all("-",".") -> NowTime 
    
    message(stringr::str_c("Autotunning Random Forest Model for Final Model.. Please be patient!",NowTime))
    eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Autotunning Random Forest Model for Final Model.. Please be patient!",NowTime))
    ddpcr::quiet(at_rf$train(task_rf.train))
    
    lubridate::now() %>% 
      stringr::str_replace_all(":",".") %>% 
      stringr::str_replace_all("-",".") -> NowTime 
    
    message(stringr::str_c("Random Forest Model Autotune Accomplished!",NowTime))
    eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Random Forest Model Autotune Accomplished!",NowTime))
    learner_rf$param_set$values <- at_rf$model$tuning_instance$result_learner_param_vals 
    # learner xgboost
    learner_xgboost <- lrn(str_c(task,".xgboost"), 
                           predict_type = pred.type,
                           predict_sets = c("train", "test"),
                           id = "xgboost")
    # auto-tune xgboost
    learner_xgboost$param_set
    learner_xgboost$param_set$values$eta = 0.1
    search_space = ps(
      subsample = p_dbl(lower = 0.5, upper = 1),
      colsample_bytree = p_dbl(lower = 0.5, upper = 1),
      max_depth = p_int(lower = 3, upper = 10),
      nrounds = p_int(lower = 2, upper = 200)
    )
    terminator = trm("evals", n_evals = AutTuneN)
    tuner = tnr(AutTuneM)
    at_xgboost = AutoTuner$new(
      learner = learner_xgboost,
      resampling = resampling,
      measure = msr(measure_key),
      search_space = search_space,
      terminator = terminator,
      tuner = tuner
    )
    
    lubridate::now() %>% 
      stringr::str_replace_all(":",".") %>% 
      stringr::str_replace_all("-",".") -> NowTime 
    
    message(stringr::str_c("Autotunning Xgboost Model for Final Model... Please be patient!",NowTime))
    eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Autotunning Xgboost Model for Final Model... Please be patient!",NowTime))
    ddpcr::quiet(at_xgboost$train(task_xgboost.train))
    
    lubridate::now() %>% 
      stringr::str_replace_all(":",".") %>% 
      stringr::str_replace_all("-",".") -> NowTime 
    
    message(stringr::str_c("Xgboost Model Autotune Accomplished!",NowTime))
    eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Xgboost Model Autotune Accomplished!",NowTime))
    learner_xgboost$param_set$values <- at_xgboost$model$tuning_instance$result_learner_param_vals
    ## learner svm
    #learner_xgboost <- lrn(str_c(task,"svm"),
    #                       predict_type = pred.type,
    #                       predict_type = pred.type,
    #                       predict_sets = c("train", "test"))
    ## auto-tune svm
    #learner_svm$param_set
    #
    #search_space = ps(
    #
    #)
    #terminator = trm("evals", n_evals = AutTuneN)
    #tuner = tnr(AutTuneM)
    #at_svm = AutoTuner$new(
    #  learner = learner_svm,
    #  resampling = resampling,
    #  measure = msr(measure_key),
    #  search_space = search_space,
    #  terminator = terminator,
    #  tuner = tuner
    #)
    #at_svm$train(task_svm, row_ids = train_set)
    #learner_svm$param_set$values <- at_svm$model$tuning_instance$result_learner_param_vals
    
    
    # benchmarking
    design = benchmark_grid(
      tasks = c(task_lasso.train,
                task_elasticnet.train,
                task_rf.train,
                task_xgboost.train),
      learners = c(learner_lasso,
                   learner_elasticnet,
                   learner_rf,
                   learner_xgboost),
      resamplings = resampling
    )
    
    lubridate::now() %>% 
      stringr::str_replace_all(":",".") %>% 
      stringr::str_replace_all("-",".") -> NowTime 
    
    message(stringr::str_c("Running Benchmark...Please be Patient",NowTime))
    eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Running Benchmark...Please be Patient",NowTime))
    ddpcr::quiet(benchmark(design[map_chr(design$task,~.$id)==map_chr(design$learner,~.$id)]) -> eSet$MulOmics[[OmicGroup]]$Models$Measures$bmr)
    
    lubridate::now() %>% 
      stringr::str_replace_all(":",".") %>% 
      stringr::str_replace_all("-",".") -> NowTime 
    
    message(stringr::str_c("Benchmark Accomplished!",NowTime))
    eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Benchmark Accomplished!",NowTime))
    measures_bmr = list(msr(measure_key, predict_sets = "train", id = str_c(measure_id,"_train")),
                        msr(measure_key, id =str_c(measure_id,"_test") ))
    eSet$MulOmics[[OmicGroup]]$Models$Measures$bmr$aggregate(measures_bmr) %>% 
      mutate(learners = c("Lasso",
                          "Elastic net",
                          "Random forest",
                          "Xgboost"),
             RsmpMethod = map2_chr(resampling_id,
                                        iters,
                                        ~str_c(.x,"-",.y))) %>% 
      dplyr::select(learners,
             RsmpMethod,
             str_c(measure_id,"_train"),
             str_c(measure_id,"_test")) -> eSet$MulOmics[[OmicGroup]]$Models$Measures$stat
    
    eSet$MulOmics[[OmicGroup]]$Models$Measures$stat %>% 
      writexl::write_xlsx(str_c(Path,"/",
                                OmicGroup,
                                "/Model_Summary/Measures_stat.xlsx"))
    
    # save predictions
    # lasso
    learner_lasso$predict(task_lasso.train)$response -> eSet$MulOmics[[OmicGroup]]$Models$Predictions$lasso$train_set
    learner_lasso$predict_newdata(df.all.test)$response -> eSet$MulOmics[[OmicGroup]]$Models$Predictions$lasso$test_set
    
    # elastic net
    learner_elasticnet$predict(task_elasticnet.train)$response -> eSet$MulOmics[[OmicGroup]]$Models$Predictions$elasticnet$train_set
    learner_elasticnet$predict_newdata(df.all.test)$response -> eSet$MulOmics[[OmicGroup]]$Models$Predictions$elasticnet$test_set
    
    # randomforest
    learner_rf$train(task_rf.train)
    learner_rf$predict(task_rf.train)$response -> eSet$MulOmics[[OmicGroup]]$Models$Predictions$rf$train_set
    learner_rf$predict_newdata(newdt_rf.test)$response -> eSet$MulOmics[[OmicGroup]]$Models$Predictions$rf$test_set
    
    # xgboost
    learner_xgboost$train(task_xgboost.train)
    learner_xgboost$predict(task_xgboost.train)$response -> eSet$MulOmics[[OmicGroup]]$Models$Predictions$xgboost$train_set
    learner_xgboost$predict_newdata(newdt_xgboost.test)$response -> eSet$MulOmics[[OmicGroup]]$Models$Predictions$xgboost$test_set

    ## svm
    #learner_svm$train(task_svm, row_ids = train_set)
    #learner_svm$predict(task_svm, row_ids = train_set)$response -> eSet$MulOmics[[OmicGroup]]$Models$Predictions$svm$train_set
    #learner_svm$predict(task_svm, row_ids = test_set)$response -> eSet$MulOmics[[OmicGroup]]$Models$Predictions$svm$test_set 
    
    # Save explainer
    if(!file.exists(str_c(Path,"/",OmicGroup,"/Feature_Explain/Lasso"))){
      dir.create(str_c(Path,"/",OmicGroup,"/Feature_Explain/Lasso"))
    }
    
    if(!file.exists(str_c(Path,"/",OmicGroup,"/Feature_Explain/Elastic net"))){
      dir.create(str_c(Path,"/",OmicGroup,"/Feature_Explain/Elastic net"))
    }
    
    if(!file.exists(str_c(Path,"/",OmicGroup,"/Feature_Explain/Randomforest"))){
      dir.create(str_c(Path,"/",OmicGroup,"/Feature_Explain/Randomforest"))
    }
    
    if(!file.exists(str_c(Path,"/",OmicGroup,"/Feature_Explain/Xgboost"))){
      dir.create(str_c(Path,"/",OmicGroup,"/Feature_Explain/Xgboost"))
    }
    # Lasso
    ddpcr::quiet(
      expl_ls <- DALEX::explain(model = learner_lasso$model,
                                data = df.all.train %>% dplyr::select(all_of(VarsX),all_of(VarsC)) %>% as.matrix(),
                                y = df.all.train %>% dplyr::select(VarY) %>% as.matrix() %>% as.numeric(),
                                label = "Lasso"))
    expl_ls -> eSet$MulOmics[[OmicGroup]]$Models$Explainer$expl_lasso
    # Importance
    ddpcr::quiet(
      model_parts(explainer = expl_ls,
                  loss_function = loss_default(expl_ls$model_info$type),
                  B=10,
                  type = "difference") -> eSet$MulOmics[[OmicGroup]]$Models$Explainer$importance_lasso
    )
    eSet$MulOmics[[OmicGroup]]$Models$Explainer$importance_lasso %>% 
      writexl::write_xlsx(stringr::str_c(Path,"/",
                                         OmicGroup,
                                         "/Feature_Explain/Lasso/Importance_lasso.xlsx"))
    # Elastic net
    ddpcr::quiet(
      expl_elasticnet <- DALEX::explain(model = learner_elasticnet$model,
                                data = df.all.train %>% dplyr::select(all_of(VarsX),all_of(VarsC)) %>% as.matrix(),
                                y = df.all.train %>% dplyr::select(VarY) %>% as.matrix() %>% as.numeric(),
                                label = "Elastic net"))
    expl_elasticnet -> eSet$MulOmics[[OmicGroup]]$Models$Explainer$expl_elasticnet
    # Importance
    ddpcr::quiet(
      model_parts(explainer = expl_elasticnet,
                  loss_function = loss_default(expl_elasticnet$model_info$type),
                  B=10,
                  type = "difference") -> eSet$MulOmics[[OmicGroup]]$Models$Explainer$importance_elasticnet
    )
    eSet$MulOmics[[OmicGroup]]$Models$Explainer$importance_elasticnet %>% 
      writexl::write_xlsx(stringr::str_c(Path,"/",
                                         OmicGroup,
                                         "/Feature_Explain/Elastic net/Importance_elasticnet.xlsx"))
    # Randomforest
    ddpcr::quiet(
    expl_rf <- DALEX::explain(model = learner_rf$model,
                              data = df.all.train %>% dplyr::select(features_rf) %>% as.matrix(),
                              y = df.all.train %>% dplyr::select(VarY) %>% as.matrix() %>% as.numeric(),
                              label = "Randomforest"))

    expl_rf -> eSet$MulOmics[[OmicGroup]]$Models$Explainer$expl_rf
      # Importance
    ddpcr::quiet(
        model_parts(explainer = expl_rf,
                    loss_function = loss_default(expl_rf$model_info$type),
                    B=10,
                    type = "difference") -> eSet$MulOmics[[OmicGroup]]$Models$Explainer$importance_rf
        )
        
        eSet$MulOmics[[OmicGroup]]$Models$Explainer$importance_rf %>% 
          writexl::write_xlsx(stringr::str_c(Path,"/",
                                             OmicGroup,
                                             "/Feature_Explain/Randomforest/Importance_rf.xlsx"))
    # Xgboost
    ddpcr::quiet(
    expl_xgboost <- DALEX::explain(model = learner_xgboost$model,
                                   data = df.all.train %>% dplyr::select(learner_xgboost$model$feature_names) %>% as.matrix(),
                                   y = df.all.train %>% dplyr::select(VarY) %>% as.matrix() %>% as.numeric(),
                                   label = "Xgboost"))
    expl_xgboost -> eSet$MulOmics[[OmicGroup]]$Models$Explainer$expl_xgboost
      # Importance
    ddpcr::quiet(
      model_parts(explainer = expl_xgboost,
                  loss_function = loss_default(expl_xgboost$model_info$type),
                  B=10,
                  type = "difference") -> eSet$MulOmics[[OmicGroup]]$Models$Explainer$importance_xgboost)
      eSet$MulOmics[[OmicGroup]]$Models$Explainer$importance_xgboost %>% 
        writexl::write_xlsx(stringr::str_c(Path,"/",
                                           OmicGroup,
                                           "/Feature_Explain/Xgboost/Importance_xgboost.xlsx"))
      
    # save models
    list(lasso = learner_lasso,
         elasticnet = learner_elasticnet,
         rf = learner_rf,
         xgboost = learner_xgboost) -> eSet$MulOmics[[OmicGroup]]$Models$learners
    
    lubridate::now() %>% 
      stringr::str_replace_all(":",".") %>% 
      stringr::str_replace_all("-",".") -> NowTime 
    
    message(stringr::str_c("Machine learning models for ",OmicGroup," completed!",NowTime))
    eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Machine learning models for ",OmicGroup," completed!",NowTime))
    return(eSet)
  }
  map(OmicGroups,
      single.omics,
      VarY = VarY,
      VarsC = VarsC,
      AutTuneM = AutTuneM,
      AutTuneN = AutTuneN,
      task = task,
      pred.type,
      measure_key = measure_key,
      measure_id = measure_id,
      set_task = set_task,
      resampling = resampling)



  eSet %>% 
    save(file = str_c(eSet$FileDirOut,"/eSet.Rdata"))
  
return(eSet)
}


