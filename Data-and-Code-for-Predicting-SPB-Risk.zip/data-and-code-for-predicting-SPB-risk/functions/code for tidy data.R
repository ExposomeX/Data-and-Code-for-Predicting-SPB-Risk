Tidydata <- function(eSet){
  
  tictoc::tic()
  lubridate::now() %>% 
    stringr::str_replace_all(":",".") %>% 
    stringr::str_replace_all("-",".") -> NowTime 
  
  path = stringr::str_c(eSet$FileDirOut, "/2_tidy data")
  if(!file.exists(path)) {dir.create(path)}
  
  
    eSet$Expo$Data %>% 
      naniar::miss_var_summary() %>% 
      dplyr::filter(n_miss > 0) %>% 
      purrr::set_names("SerialNo", 
                       "number_miss", 
                       "percent_miss") -> temp1
    temp1 -> eSet$StatMiss
    
    #save the missing information
    if(nrow(temp1) > 0){
      ddpcr::quiet(
        temp1 %>% 
          vroom::vroom_write(stringr::str_c(path, "/StatMissing.csv"),
                             delim = ",")
      )
    }
    
    #update the kept and delete dexposome datasets
    if(length(eSet$ExpoDel$Data) > 0){
      eSet$ExpoDel$Data %>% 
        cbind(eSet$Expo$Data  %>% 
                dplyr::select(temp1$SerialNo)) %>% 
        as_tibble() -> eSet$ExpoDel$Data
      
      
      eSet$ExpoDel$Voca %>% 
        rbind(eSet$Expo$Voca  %>%
                dplyr::filter(SerialNo %in% temp1$SerialNo)) ->  eSet$ExpoDel$Voca
    }else{
      eSet$Expo$Data  %>% 
        dplyr::select(temp1$SerialNo)-> eSet$ExpoDel$Data
      
      
      eSet$Expo$Voca  %>%
        dplyr::filter(SerialNo %in% temp1$SerialNo) ->  eSet$ExpoDel$Voca
    }
    
    
    eSet$Expo$Data  %>%  
      dplyr::select(-temp1$SerialNo) -> eSet$Expo$Data
    
    eSet$Expo$Voca  %>%  
      dplyr::filter(!SerialNo %in% temp1$SerialNo) ->  eSet$Expo$Voca
    
    ddpcr::quiet(
      eSet$Expo$Data %>% 
        vroom::vroom_write(stringr::str_c(path, "/ExpoData_",NowTime,".csv"),
                           delim = ",")
    )
    
    ddpcr::quiet(
      eSet$Expo$Voca  %>% 
        vroom::vroom_write(stringr::str_c(path, "/ExpoVoca_",NowTime,".csv"),
                           delim = ",")
    )
    
    ddpcr::quiet(
      eSet$ExpoDel$Data %>% 
        vroom::vroom_write(stringr::str_c(path, "/ExpoDataDeleted_",NowTime,".csv"),
                           delim = ",")
    )
    
    ddpcr::quiet(
      eSet$ExpoDel$Voca  %>% 
        vroom::vroom_write(stringr::str_c(path, "/ExpoVocaDeleted_",NowTime,".csv"),
                           delim = ",")
    )
    
    #save updated variables 
    eSet$Expo$Voca %>% 
      dplyr::select(SerialNo:FullName) %>% 
      dplyr::filter(SerialNo != "Group") %>% 
      data.table::fwrite(stringr::str_c(eSet$FileDirOut,"/variables.csv")) 
    
    #print message and save log
    message("Delete ", nrow(temp1)," from ", ncol(eSet$Expo$Data)+nrow(temp1), 
            " features (remainning:", ncol(eSet$Expo$Data),") with missing values > 1.", " ", 
            NowTime, "\n")
    
    eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Delete ", nrow(temp1)," in ",
                                                      ncol(eSet$Expo$Data),
                                                      " features with missing values > 1. ", 
                                                      NowTime))
    
      
    eSet %>% 
      save(file = str_c(eSet$FileDirOut,"/eSet.Rdata"))
    
    tictoc::tic() 
    lubridate::now() %>% 
      stringr::str_replace_all(":",".") %>% 
      stringr::str_replace_all("-",".") -> NowTime 
    
    path = stringr::str_c(eSet$FileDirOut,"/2_tidy data")
    if(!file.exists(path)) {dir.create(path)}

         #get the Vars names
      if(nrow(eSet$Expo$Data) > 0){
        quiet(names(eSet$Expo$Data) %>% 
                stringr::str_extract_all("^[XCM].*",
                                         simplify = T) %>% 
                as_tibble() %>% 
                dplyr::filter(V1 != "") %>% 
                .$V1 -> VarsXCM)
        
        names(eSet$Expo$Data) %>% 
          stringr::str_extract_all("^[SYCXMG].*",
                                   simplify = T) %>% 
          as_tibble() %>% 
          dplyr::filter(V1 != "") %>% 
          .$V1 -> Vars.all
        
        #get the names of the deleted features
        eSet$Expo$Data %>% 
          dplyr::select(all_of(VarsXCM)) %>% 
          caret::nearZeroVar(saveMetrics = T,
                             names = T) %>% 
          dplyr::filter(nzv == "TRUE") %>% 
          rownames() -> VarsDeleted
        
        #get the kept and deleted data
        eSet$Expo$Data %>% 
          dplyr::select(all_of(VarsDeleted)) -> eSet$ExpoDel$Data
        eSet$Expo$Voca%>% 
          dplyr::filter(SerialNo %in% VarsDeleted) -> eSet$ExpoDel$Voca
        
        eSet$Expo$Data %>% 
          dplyr::select(-all_of(VarsDeleted)) -> eSet$Expo$Data
        eSet$Expo$Voca%>% 
          dplyr::filter(!SerialNo %in% VarsDeleted) -> eSet$Expo$Voca
        
        ddpcr::quiet(
          eSet$Expo$Data %>% 
            vroom::vroom_write(stringr::str_c(path, "/ExpoData_", NowTime,".csv"),
                               delim = ",")
        )
        
        ddpcr::quiet(
          eSet$Expo$Voca %>% 
            vroom::vroom_write(stringr::str_c(path, "/ExpoVoca_", NowTime,".csv"),
                               delim = ",")
        )
        
        ddpcr::quiet(
          eSet$ExpoDel$Data %>% 
            vroom::vroom_write(stringr::str_c(path, "/ExpoDataDeleted_", NowTime,".csv"),
                               delim = ",")
        )
        
        ddpcr::quiet(
          eSet$ExpoDel$Voca %>% 
            vroom::vroom_write(stringr::str_c(path, "/ExpoVocaDeleted_", NowTime,".csv"),
                               delim = ",")
        )
        
        message("Delete ", ncol(eSet$ExpoDel$Data)," from ",
                ncol(eSet$Expo$Data)+ncol(eSet$ExpoDel$Data), " features (remainning: ",
                ncol(eSet$Expo$Data), ") with zero or near zero variance. ", 
                NowTime, "\n")
        
        eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Delete ", ncol(eSet$ExpoDel$Data)," from ",
                                                          ncol(eSet$Expo$Data)+ncol(eSet$ExpoDel$Data), " features (remainning: ",
                                                          ncol(eSet$Expo$Data), ") with zero or near zero variance. ",  
                                                          NowTime))
      }else{
        message("Error: The exposome data is empty! ", NowTime, "\n")
        eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Error: The exposome data is empty! ", NowTime))
      }
      

      #save updated variables 
      eSet$Expo$Voca %>% 
        dplyr::select(SerialNo:FullName) %>% 
        dplyr::filter(SerialNo != "Group") %>% 
        data.table::fwrite(stringr::str_c(eSet$FileDirOut,"/variables.csv")) 
      
      eSet %>% 
        save(file = str_c(eSet$FileDirOut,"/eSet.Rdata"))
      
      tictoc::toc()
      
      return(eSet)

}


