CrosAsso <- function(eSet,
                     VarsY, 
                     VarsX,
                     VarsSel,
                     VarsSelThr,
                     Family, #
                     RepMsr = FALSE,
                     Corstr = "ar1" #specifying the correlation structure, i.e. exchangeable ar1 unstructured userdefined 
){ 
  
  tictoc::tic()

  lubridate::now() %>% 
    stringr::str_replace_all(":",".") %>% 
    stringr::str_replace_all("-",".") -> NowTime 
  
  path = stringr::str_c(eSet$FileDirOut, "/5_screen association")
  if(!file.exists(path)) {dir.create(path)}

  # define VarsX and VarsC-------------------------------------------------------------
  if (VarsX[1]=="all.x")  {
            eSet$Expo$Voca %>% 
              dplyr::filter(str_detect(SerialNo_Raw, "[X]")) %>% 
              .$SerialNo -> VarsX
  }else{
    eSet$Expo$Voca %>% 
      dplyr::filter(SerialNo_Raw %in% VarsX) %>% 
      .$SerialNo -> VarsX    
          }

  # define data -------------------------------------------------------------
  eSet$Expo$Data -> df.all
  
  VarsC = NULL


  # Func_GetSFModel -------------------------------------------------------------
  Func_GetSFModel <- function(Var){
    stringr::str_c(VarsY, "~", 
          stringr::str_c(c(VarsC, Var), collapse = "+")) %>% 
      as_tibble() %>% 
      rename(formula = value) -> temp
    return(temp)
  }

  
  #The code of function: My.stepwise.glm is sourced from the package "My.stepwise"
  My.stepwise.glm <- function(Y,
                              variable.list, 
                              in.variable = "NULL", 
                              data, 
                              sle = 0.20, 
                              sls = 0.20, 
                              myfamily, 
                              myoffset = "NULL"){
    univar.pvalue <- NULL
    temp.model <- NULL
    lr.pvalue <- NULL
    if (myfamily == "binomial") 
      initial.model <- glm(as.formula(paste(Y, paste(in.variable, 
                                                     collapse = "+"), sep = "~")), data = data, family = binomial(logit))
    if (myfamily == "poisson" & myoffset != "") 
      initial.model <- glm(as.formula(paste(Y, " ~ offset(log(", 
                                            myoffset, ")) + ", paste(in.variable, collapse = "+"), 
                                            sep = "")), data = data, family = poisson(log))
    if (myfamily == "poisson" & myoffset == "") 
      initial.model <- glm(as.formula(paste(Y, paste(in.variable, 
                                                     collapse = "+"), sep = "~")), data = data, family = poisson(log))
    if (sum(is.na(initial.model$coefficients)) == 0 & summary(initial.model)$iter < 
        12) {
      temp.model <- initial.model
      cat("# --------------------------------------------------------------------------------------------------\n")
      cat("# Initial Model:\n")
      print(summary(temp.model))
      if (length(summary(temp.model)$coefficients[, 1]) > 2) 
        print(car::vif(temp.model))
      i <- 0
      break.rule <- TRUE
      while (break.rule) {
        i <- i + 1
        if (i == 1) {
          variable.list2 <- setdiff(variable.list, all.vars(temp.model$formula))
        }
        else {
          variable.list2 <- setdiff(variable.list, c(all.vars(temp.model$formula), 
                                                     out.x))
          out.x <- NULL
        }
        if (length(variable.list2) != 0) {
          lr.pvalue <- NULL
          mv.pvalue <- NULL
          for (k in 1:length(variable.list2)) {
            model <- update(temp.model, as.formula(paste(". ~ . + ", 
                                                         variable.list2[k], sep = "")))
            if (sum(is.na(model$coefficients)) != 0) {
              lr.pvalue[k] <- 1
              mv.pvalue[k] <- 1
            }
            else {
              lr.pvalue[k] <- lmtest::lrtest(temp.model, model)["Pr(>Chisq)"][2, 
                                                                              1]
              mv.pvalue[k] <- summary(model)$coefficients[nrow(summary(model)$coefficients), 
                                                          "Pr(>|z|)"]
            }
          }
          variable.list2.1 <- variable.list2[mv.pvalue <= 
                                               0.9 & !is.na(mv.pvalue)]
          lr.pvalue2 <- lr.pvalue[mv.pvalue <= 0.9 & !is.na(mv.pvalue)]
          mv.pvalue2 <- mv.pvalue[mv.pvalue <= 0.9 & !is.na(mv.pvalue)]
          enter.x <- variable.list2.1[lr.pvalue2 == min(lr.pvalue2, 
                                                        na.rm = TRUE) & lr.pvalue2 <= sle]
          wald.p <- mv.pvalue2[lr.pvalue2 == min(lr.pvalue2, 
                                                 na.rm = TRUE) & lr.pvalue2 <= sle]
          enter.x <- setdiff(enter.x, NA)
          if (length(enter.x) != 0) {
            if (length(enter.x) > 1) {
              enter.x <- enter.x[which.min(wald.p)]
            }
            cat("# --------------------------------------------------------------------------------------------------", 
                "\n")
            cat(paste("### iter num = ", i, ", Forward Selection by LR Test: ", 
                      "+ ", enter.x, sep = ""), "\n")
            temp.model <- update(temp.model, as.formula(paste(". ~ . + ", 
                                                              enter.x, sep = "")))
            print(summary(temp.model))
            cat(paste("--------------- Variance Inflating Factor (VIF) ---------------"), 
                "\n")
            cat("Multicollinearity Problem: Variance Inflating Factor (VIF) is bigger than 10 (Continuous Variable) or is bigger than 2.5 (Categorical Variable)\n")
            if (length(summary(temp.model)$coefficients[, 
                                                        1]) > 2) 
              print(car::vif(temp.model))
            if (summary(temp.model)$iter >= 12) 
              break
          }
        }
        else {
          enter.x <- NULL
        }
        variable.list3 <- setdiff(rownames(summary(temp.model)$coefficients), 
                                  c(enter.x, "(Intercept)", in.variable))
        if (length(variable.list3) != 0) {
          lr.pvalue <- NULL
          for (k in 1:length(variable.list3)) {
            model <- update(temp.model, as.formula(paste(". ~ . - ", 
                                                         variable.list3[k], sep = "")))
            lr.pvalue[k] <- lmtest::lrtest(temp.model, model)["Pr(>Chisq)"][2, 
                                                                            1]
          }
          out.x <- variable.list3[lr.pvalue == max(lr.pvalue, 
                                                   na.rm = TRUE) & lr.pvalue > sls]
          out.x <- setdiff(out.x, NA)
          if (length(out.x) != 0) {
            if (length(out.x) > 1) {
              out.x.1 <- out.x
              for (j in 1:length(out.x)) {
                out.x[j] <- out.x.1[(length(out.x) - j + 
                                       1)]
              }
              wald.p <- rep(NA, length(out.x))
              for (j in 1:length(out.x)) {
                wald.p[j] <- summary(temp.model)$coefficients[, 
                                                              "Pr(>|z|)"][rownames(summary(temp.model)$coefficients) == 
                                                                            out.x[j]]
              }
              out.x <- out.x[which.max(wald.p)]
            }
            cat("# --------------------------------------------------------------------------------------------------", 
                "\n")
            cat(paste("### iter num = ", i, ", Backward Selection by LR Test: ", 
                      "- ", out.x, sep = ""), "\n")
            temp.model <- update(temp.model, as.formula(paste(". ~ . - ", 
                                                              out.x, sep = "")))
            print(summary(temp.model))
            cat(paste("--------------- Variance Inflating Factor (VIF) ---------------"), 
                "\n")
            cat("Multicollinearity Problem: Variance Inflating Factor (VIF) is bigger than 10 (Continuous Variable) or is bigger than 2.5 (Categorical Variable)\n")
            if (length(summary(temp.model)$coefficients[, 
                                                        1]) > 2) 
              print(car::vif(temp.model))
          }
        }
        else {
          out.x <- NULL
        }
        if ((length(enter.x) + length(out.x)) == 0) {
          final.model <- temp.model
          cat("# ==================================================================================================", 
              "\n")
          cat(paste("*** Stepwise Final Model (in.lr.test: sle = ", 
                    sle, "; out.lr.test: sls = ", sls, "):", sep = ""), 
              "\n")
          print(summary(final.model))
          cat(paste("--------------- Variance Inflating Factor (VIF) ---------------"), 
              "\n")
          cat("Multicollinearity Problem: Variance Inflating Factor (VIF) is bigger than 10 (Continuous Variable) or is bigger than 2.5 (Categorical Variable)\n")
          if (length(summary(final.model)$coefficients[, 
                                                       1]) > 2) 
            print(car::vif(final.model))
          break.rule <- FALSE
        }
        enter.x <- NULL
      }
    }
    else {
      cat("# ==================================================================================================\n")
      cat("# Initial Model:\n")
      print(summary(initial.model))
    }
    return(final.model)
  }
  

  
  #Excecute 

    # SingleFactor ---------------------------------------------------------
 
     VarsY -> eSet$CrosAsso$SingleFactor$VarsY

     if(!RepMsr){
              message("Pls be patient. It will take about ", length(VarsX)*0.6/60, " mins \n")
              map_dfr(VarsX, Func_GetSFModel) %>% 
                mutate(model = map(formula,
                                   ~glm(.x,
                                        data = df.all,
                                        family = Family) 
                                   )
                       )  %>% 
                mutate(res = map(model, ~tidy(.x))) %>% 
                unnest(res) %>% 
                dplyr::filter(stringr::str_detect(term, "X")) %>% 
                dplyr::mutate(SerialNo = term) %>% 
                dplyr::mutate(SerialNo = stringr::str_remove(SerialNo, "\\..*")) %>% 
                rename(Vars.dummy = term) %>% 
                dplyr::mutate(ci_l = estimate - 1.96*std.error,
                              ci_h = estimate + 1.96*std.error) %>% 
                dplyr::mutate(term1 = stringr::str_remove(Vars.dummy, "X"),
                              term1 = as.numeric(term1)) %>% 
                arrange(term1) %>% 
                dplyr::select(SerialNo, 
                              Vars.dummy,
                              estimate, 
                              ci_l,
                              ci_h,
                              p.value,
                              std.error,
                              formula,
                              model) %>% 
                rename(beta.value = estimate) -> eSet$CrosAsso$SingleFactor$Stat_ModelSum
              }else{
                message("Pls be patient. It will take about ", length(VarsX)*0.6/60, " mins \n")

                map_dfr(VarsX, Func_GetSFModel) %>% 
                  mutate(model = map(formula,
                                     ~geeglm(as.formula(.x),
                                             id = SubjectID,
                                             data = df.all %>% 
                                               mutate(across(all_of(VarsY), as.character))%>% 
                                               mutate(across(all_of(VarsY), as.numeric)) %>% 
                                               arrange(SubjectID),
                                             family = Family,
                                             corstr = Corstr) 
                                     )
                         )  %>% 
                  mutate(res = map(model, ~tidy(.x))) %>% 
                  unnest(res) %>% 
                  dplyr::filter(stringr::str_detect(term, "X")) %>% 
                  dplyr::mutate(SerialNo = term) %>% 
                  dplyr::mutate(SerialNo = stringr::str_remove(SerialNo, "\\..*")) %>% 
                  rename(Vars.dummy = term) %>% 
                  dplyr::mutate(ci_l = estimate - 1.96*std.error,
                                ci_h = estimate + 1.96*std.error) %>% 
                  dplyr::mutate(term1 = stringr::str_remove(Vars.dummy, "X"),
                                term1 = as.numeric(term1)) %>% 
                  arrange(term1) %>% 
                  dplyr::select(SerialNo, 
                                Vars.dummy,
                                estimate, 
                                ci_l,
                                ci_h,
                                p.value,
                                std.error,
                                formula,
                                model)  %>% 
                  rename(beta.value = estimate) -> eSet$CrosAsso$SingleFactor$Stat_ModelSum
            
            }
     
     

 eSet$CrosAsso$SingleFactor$Stat_ModelSum %<>%  
                    mutate(OR = exp(beta.value),
                           OR_CI_L = exp(ci_l),
                           OR_CI_H = exp(ci_h))
                  
     
     eSet$CrosAsso$SingleFactor$Stat_ModelSum %>% 
       dplyr::filter(p.value < 0.05) %>% 
       dplyr::select(SerialNo) %>% 
       dplyr::filter(SerialNo %in% VarsX) -> eSet$CrosAsso$SingleFactor$Stat_SigFeature
     
     eSet$CrosAsso$SingleFactor$Stat_ModelSum %>% 
       dplyr::filter(p.value < 0.05/length(VarsX)) %>% 
       dplyr::select(SerialNo) %>% 
       dplyr::filter(SerialNo %in% VarsX) -> eSet$CrosAsso$SingleFactor$Stat_SigFeature_FDR_Corrected
     
     eSet$CrosAsso$SingleFactor$Stat_ModelSum  %>%  
       dplyr::left_join(eSet$Expo$Voca %>% 
                   dplyr::select(SerialNo_Raw, FullName, GroupName),
                 by = c("SerialNo" = "SerialNo_Raw")) %>% 
       dplyr::distinct(SerialNo,
                       Vars.dummy,
                       .keep_all = T) -> eSet$CrosAsso$SingleFactor$Stat_ModelSum
     
     ddpcr::quiet(
       eSet$CrosAsso$SingleFactor$Stat_ModelSum %>% 
       vroom::vroom_write(stringr::str_c(path, "/Full_", all_of(VarsY),  "_single.factor_",
                                eSet$EpiDesign, "_", Family,"_", NowTime, ".csv"),
                          delim = ","))
     
     ddpcr::quiet(
       eSet$CrosAsso$SingleFactor$Stat_ModelSum %>% 
         dplyr::select(SerialNo, Vars.dummy, FullName,10:12,6) %>% 
         vroom::vroom_write(stringr::str_c(path, "/Web_", all_of(VarsY),  "_single.factor_",
                                           eSet$EpiDesign, "_", Family,"_", NowTime, ".csv"),
                            delim = ","))
    
  
   #print message and save log
  message("Complete modeling of ", Family, ". ", NowTime, "\n")
  eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Complete modeling of ",Family, ". ", NowTime))
 
   eSet %>% 
    save(file = str_c(eSet$FileDirOut,"/eSet.Rdata"))
  
  tictoc::toc()
  
  return(eSet)
  
}