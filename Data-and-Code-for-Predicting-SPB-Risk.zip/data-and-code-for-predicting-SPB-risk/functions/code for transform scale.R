
TransScale <- function(eSet,
                       Vars,
                       Method
                       ){
  tictoc::tic()
  lubridate::now() %>% 
    stringr::str_replace_all(":",".") %>% 
    stringr::str_replace_all("-",".") -> NowTime 
  
  path = stringr::str_c(eSet$FileDirOut, "/4_transform scale")
  if(!file.exists(path)) {dir.create(path)}

    
  # Define data -----------------------------------------------------------------------------
  eSet$Expo$Data  -> df.all
  
  
  switch (Vars[1],
          "all.c" = {
            eSet$Expo$Voca %>% 
              dplyr::filter(str_detect(SerialNo_Raw, "[C]")) %>% 
              .$SerialNo -> Vars
          },
          "all.x" = {
            eSet$Expo$Voca %>% 
              dplyr::filter(str_detect(SerialNo_Raw, "[X]")) %>% 
              .$SerialNo -> Vars
          },
          "all.cx" = {
            eSet$Expo$Voca %>% 
              dplyr::filter(str_detect(SerialNo_Raw, "[CX]")) %>% 
              .$SerialNo -> Vars
          }
  )
  
  # Define Functions
  FuncScaleNormal <- function(Var, df){
    df %>% 
      dplyr::select(all_of(Var)) %>% 
      scale() %>% 
      as_tibble() -> temp
  }
  
# execute -----------------------------------------------------------------
           df.all %>%  
             dplyr::select(all_of(Vars)) %>% 
             dplyr::select(where(is.numeric)) %>% 
             names() -> Vars
           

            #calculate all dataset
             if(length(Vars) > 0){
                purrr::map_dfc(Vars, 
                        FuncScaleNormal,
                        df = df.all) -> df.temp
                
               df.all %>%  
                 dplyr::select(-all_of(Vars)) %>% 
                 cbind(df.temp) %>% 
                 as_tibble() %>% 
                 dplyr::select(names(df.all)) -> eSet$Expo$Data
              }else{
                message(stringr::str_c("Error: These group of Variables cann't be scaled!",
                                       lubridate::now()), "\n")
              }
           
         
        

  #save data
  ddpcr::quiet(
    eSet$Expo$Data %>%
    vroom::vroom_write(stringr::str_c(path, "/Data_TransScaleTo_",  NowTime, ".csv"),
                       delim = ",")
  )
    
  ddpcr::quiet(
    eSet$Expo$Voca %>%
      vroom::vroom_write(stringr::str_c(path, "/Voca_TransScaleTo_", NowTime, ".csv"),
                       delim = ",")
  )
  
  #print message and save log
  message("Complete transform -> scale! ", NowTime, "\n")
  eSet$ExcecutionLog  <- eSet$AddLog(stringr::str_c("Complete transform -> scale! ", NowTime))
  
  eSet %>% 
    save(file = str_c(eSet$FileDirOut,"/eSet.Rdata"))
  
  tictoc::toc()
  
  return(eSet)
}






